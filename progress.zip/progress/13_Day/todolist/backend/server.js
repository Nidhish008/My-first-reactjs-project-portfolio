const express = require("express")
const app = express()
const DB = require('./db/db')
const todoSchema = require("./models/schema")
const cors = require("cors")
app.use(cors())
app.use(express.json())
app.get("/api/v1/todo", async(req, res) => {
    await DB()
    const task = await todoSchema.find({})
    console.log(task);
    res.json(task)
})
app.put("/api/v1/todo/:id", async(req, res) => {
    let id = req.params.id
    let response = await todoSchema.updateOne({ _id: id }, {
        $set: { task: req.body.task }
    })
    res.json(response)
})

app.post("/api/v1/todo", async(req, res) => {
    await DB()
    const body = await req.body
    console.log(body);
    const status = await todoSchema.create(body)
    res.json(status)
})
app.delete("/api/v1/todo/:id", async(req, res) => {
    let i = req.params.id
    let response = await todoSchema.deleteOne({ _id: i })
    res.json(response)
})

app.listen(3000, () => {
    console.log("server is running")
})