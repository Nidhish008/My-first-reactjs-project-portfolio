const {Schema,model}=require("mongoose");
const todoList=new Schema({
    Task:String,
});

module.exports=model("List",todoList); 