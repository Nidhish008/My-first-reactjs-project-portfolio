import React from 'react'
import { useState, useEffect } from 'react';
import axios from "axios"
import View from './View';

function Task() {
    const [value, setValue] = useState()
    const [data, setData] = useState([])
    async function getData(){
        let response = await axios.get("http://localhost:3000/api/v1/todo")
       setData(response.data)
        console.log(response)

    }
    useEffect(()=>{
        
        getData()

    }, [])
    async function handleClick(e){
        e.preventDefault();
        const res = await axios.post("http://localhost:3000/api/v1/todo", 
            {
                task:value
            })
        getData()
    }
  return (
    <div>
        <form action = " ">
            <label htmlFor='addTask'>Add Task</label><br></br><br></br>
            <input value = {value} onChange = {(e) =>setValue(e.target.value)} type = "text" id = "addtask" placeholder = "Enter task"/><br></br><br></br>
        <button onClick = {(e)=>{handleClick(e)}}>Add task</button>
        </form>
        <div>
            {data.length > 0 && data.map((i, k) => <View key={i._id} id={i._id} handleUpdate={getData} task={i.Task} />)}
            </div>
        
    </div>
  )
}

export default Task