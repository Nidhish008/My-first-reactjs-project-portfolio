var a=10;
a=true;
a="hiii";
a=[1,2,3,4];
a={"rollno":1};
console.log(a);
var str="Hello World hii";
console.log(str.length);
console.log(str.split("o"));
console.log(str.trim());
console.log(str.trim.length);
console.log(str.charAt(6));
console.log(str.indexOf("l"));
console.log(str.lastIndexOf("l"));
var newvar=10+"number";
console.log(newvar);
console.log(typeof(newvar));
console.log(typeof`${newvar}`);
var multilinestr=`ersfkn,fvds
sdcnkkk. ,.
svkjfbrfsd
dsk,jnfvd $ newvar`
console.log(multilinestr);

var float=123.45;
console.log(float);
console.log(Number.parseInt(float));
var str="nksdlcfl;"
console.log(typeof(str));
console.log(Number.parseInt(str));


//math

console.log(Math.min(1,2,3,0.5));
console.log(Math.random()); //random value between 0 to 1\
console.log(Number.parseInt(Math.random()*100));
console.log(Math.abs(-128.43));
console.log(Math.sqrt(16));
console.log(Math.cbrt(64));
console.log(Math.pow(5,3));


//boolean

var bool1=true;
var bool2=false;
console.log(bool1);
console.log(bool2);


//null

var value=null;
console.log(value);


//arrays

var arr=[1,2,"hello",[1,2,"hi"],4,5.67];
console.log(arr);
console.log(typeof(arr));
arr.push(8);
console.log(arr);
console.log(arr.pop());
console.log(arr);
arr.unshift(8);
console.log(arr);
arr.shift();
console.log(arr);


//string reverse

console.log("String:");
var s="hello"
console.log(s);
var s1=s.split("");
console.log(s1);
console.log(s1.reverse());
console.log("Reversed word:"); 
console.log(s1.join(""));

//iterations

for(var i=0;i<arr.length;i++){
    console.log(arr[i]);
}

for(var i=4;i>=0;i--){
    console.log(i);
}

var i=0;
while(i<5){
    console.log(i);
    i++;
}

do{
    console.log(i);
    i--;
}while(i>=0);

["apple","orange","mango","banana"].forEach
((i,k)=>{
    console.log(i,k);
})

if(i==0){
    console.log("Hammed");
}
else{
    console.log("Maharaja");
}

var char=prompt("Enter a character in small letters:");
char=char??"b"
switch(char){
    case 'a':
        console.log("vowel");
        break;
    case 'e':
        console.log("vowel");
        break;
    case 'i':
        console.log("vowel");
        break;
    case 'o':
        console.log("vowel");
        break;
    case 'u':
        console.log("vowel");
        break;                
    default:
        console.log("Consonant");    
}

var n=prompt("Enter a number");
console.log((n==0)?"zero":((n>0)?"Positive":"Negative"));

function f1(){
    console.log("Function is called");
}
if(n!=0)
    f1();

function multiply(val1,val2){
    return val1*val2;
}
var n1=prompt("Enter the first no:");
var n2=prompt("Enter the second no:");
var res=multiply(n1,n2);
console.log(n1+"*"+n2+"="+res);

