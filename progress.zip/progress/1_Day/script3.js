//javascript code for stone paper scissor game

let arr=["stone","paper","scissor"];
let userchoice=prompt("Enter your choice:");
userchoice=userchoice.toLowerCase();
if(userchoice!="stone" || userchoice!="paper" || userchoice!="scissor"){
    console.log("Invalid choice by user");
}
let computerch=Math.random()*3;
let computerchoice="";
computerch=Math.floor(computerch);
computerchoice=arr[computerch];
console.log("User choice:"+userchoice);
console.log("Computer choice:"+computerchoice);
if(userchoice==computerchoice){
    console.log("Same choice by both of them");
}
else if((userchoice==='stone' && computerchoice==='scissor') || (userchoice==='paper' && computerchoice==='stone') ||(userchoice==='scissor' && computerchoice==='paper')){
    console.log("User wins");
}
else{
    console.log("Computer wins");
}


