console.log(check);
var check=10;

var check="string";

//var allows to change the datatype of variables and redeclare them.but using let variable prevents that

let check1=10;
// let check1=20; returns in error
console.log(check1);

const var1=10;
// var1=30; returns an error as const variable cannot be changed.
console.log(var1);

const addvalue=(v1,v2)=>{
    console.log(v1+v2);
}
addvalue(1,5);

let arr=[1,2,3,4,5];
let sum=0;
function sumofarray(arr){
    for(var i=0;i<arr.length;i++){
        console.log(arr[i]);
        sum+=arr[i];
    }
    return sum;
}
var res=sumofarray(arr);
console.log(res);

sum=0;
const addarray=(arr)=>{
    for(var i=0;i<arr.length;i++){
        sum+=arr[i];
    }
    console.log(sum);
}
addarray(arr);

let compute=arr.map(i=>i)
console.log(compute);
console.log(arr);

let compute1=arr.filter(i=>i<4)
console.log(compute1);

//filter even no and odd no
let arr1=[1,2,3,4,5,6,7,8];
let even=arr1.filter(i=>i%2==0);
let odd=arr1.filter(i=>i%2!=0);
console.log("Even numbers:");
console.log(even);
console.log("Odd numbers:");
console.log(odd);

//higher order function
//every
let compute3=arr.every(i=>i<5);  //returns a boolean value
console.log(compute3);

let compute4=arr.every(i=>i<6);  //returns a boolean value
console.log(compute4);

//some
let compute5=arr.some(i=>i<5);  //returns a boolean value
console.log(compute5);

//objects
let Obj={name:"raja",rollno:1};
let Obj1={name:"raju",rollno:2};
console.log(Obj.name);
console.log(Obj.rollno);
console.log(Obj);

let {name:mo,rollno}=Obj
console.log(mo,rollno);



