export default function Newbook() {
  return <div>Newbook</div>;
}
