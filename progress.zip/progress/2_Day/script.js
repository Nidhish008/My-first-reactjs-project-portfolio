// function sayhello(){
//     console.log("HELLO");
// }

// function saybye(){
//     setTimeout(()=>{
//         console.log("BYE");
//     },5000);
// }

// //timeout is to stop it for some time
// //setinterval for repeating process on a fixed time interval

// // setInterval(()=>{
// //     sayhello();
// // },3000)

// sayhello();
// saybye();


// //eg of a interval and stopping it after 3 times

// let i=0;
// const interval=setInterval(()=>{
//     console.log(i++);
//     if(i==3){
//         clearInterval(interval);
//     }
// },3000)



