var count=0;
let inc_btn=document.getElementById("inc-btn")
let dec_btn=document.getElementById("dec-btn")
let reset_btn=document.getElementById("reset-btn")
inc_btn.addEventListener("click",()=>{
    count=count+1
    document.getElementById("count").innerText="Count : "+count
})

dec_btn.addEventListener("click",()=>{
    count=count-1
    document.getElementById("count").innerText="Count : "+count
})

reset_btn.addEventListener("click",()=>{
    count=0
    document.getElementById("count").innerText="Count : "+count
})

