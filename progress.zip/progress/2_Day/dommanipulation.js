//access a element with its id name
let h1=document.getElementById("tag2")
console.log(h1)

//text manipulation
h1.innerHTML="Hello THERE"
h1.innerText="heyy hello"
h1.textContent="Heyy there"

console.log(h1.innerHTML)
console.log(h1.innerText)
console.log(h1.textContent)
//location.assign("google.com")
console.log(screen.orientation)
history.back(1)

let div=document.createElement("div")
div.innerText="created using js"
let textNode=document.createTextNode("CREATED USING JS")
div.append(textNode)
div.className="divClass"
console.log(div)
let body=document.getElementById("data")
body.append(div)

let list=document.getElementsByClassName("one")
console.log(list)

let list1=document.querySelector("ul li")
console.log(list1)

let list2=document.querySelectorAll("ul li")
console.log(list2) 

let ul=document.createElement("ul")
let li1=document.createElement("ul")
let li2=document.createElement("ul")
let li3=document.createElement("ul")
let li4=document.createElement("ul")
let li5=document.createElement("ul")

let ol=document.createElement("ol")
let l1=document.createElement("ol")
let l2=document.createElement("ol")
let l3=document.createElement("ol")
let l4=document.createElement("ol")
ol.append(l1,l2,l3,l4)

ul.append(ol,li1,li2,li3,li4,li5)

let t1=document.createTextNode("dog")
let t2=document.createTextNode("cat")
let t3=document.createTextNode("elephant")
let t4=document.createTextNode("goat")

let text1=document.createTextNode("apple")
let text2=document.createTextNode("orange")
let text3=document.createTextNode("guava")
let text4=document.createTextNode("mango")
let text5=document.createTextNode("pineapple")
li1.append(text1)
li2.append(text2)
li3.append(text3)
li4.append(text4)
li5.append(text5)
l1.append(t1)
l2.append(t2)
l3.append(t3)
l4.append(t4)
console.log(ul)

body.append(ul)

ul.style.color="blue"
ul.style.backgroundColor="yellow"

let fruits=["jackfruit","grape","plums","strawberry"]
fruits.map((i)=>{
    let li=document.createElement("li")
    let tN=document.createTextNode(i)
    li.append(tN)
    ul.append(li)
})
body.append(ul)

body.children[0].remove()

//deleting a element in unordered list
let liii=document.getElementById("list-one")
liii.remove()


let date=new Date();
console.log(date.getDate())
console.log(date.getHours())
console.log(date.getMinutes())
console.log(date.getSeconds())


 