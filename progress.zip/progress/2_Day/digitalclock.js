function gettime() {
    let d = new Date();
    let hours = d.getHours();
    let mins = d.getMinutes();
    let sec = d.getSeconds();
    let day = d.toLocaleDateString('en-US', { weekday: 'long' });
    let date = d.toLocaleDateString();

    // Format time as HH:MM:SS
    let timeString = `${hours.toString().padStart(2,'0')}:${mins.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;

    // Update the time display
    document.getElementById("time-display").innerText=timeString;

    // Update the date and day
    document.getElementById("date").innerText="Date: "+date;
    document.getElementById("day").innerText="Day: "+day;
}

setInterval(() => {
    gettime();
}, 1000);