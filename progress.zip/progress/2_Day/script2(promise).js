let takeTicket=new Promise((resolve,reject)=>{
    if(true){
        resolve("yes booked");
    }
    else{
        reject();
    }
})

let takeTicket1=new Promise((resolve,reject)=>{
    if(false){
        resolve("yes booked");
    }
    else{
        reject();
    }
})

takeTicket.then(()=>{
    console.log("Ticket taken");
}).catch((err)=>{
    console.log(err);
})

Promise.all([takeTicket,takeTicket1]).then((e)=>console.log(e)).catch((e)=>console.log(e))

Promise.allSettled([takeTicket,takeTicket1]).then((e)=>console.log(e)).catch((e)=>{
    console.log(e);
});

const data=()=>{
    const reponse=fetch("https://jsonplaceholder.typicode.com/todos/1")
    return Response;
}


const data1=async()=>{
    let response=await fetch("https://jsonplaceholder.typicode.com/todos/1")
    response=response.json();
    console.log(response);
}

data()
data1()