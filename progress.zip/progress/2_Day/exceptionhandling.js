let button=document.getElementById("button")
button.addEventListener("click",()=>{
   alert("You clicked the button")
   console.log("button clicked")
})


 button.addEventListener("dblclick",()=>{
    alert("You double clicked the button")
    console.log("button clicked twice")
 })


 let parent=document.getElementsByClassName("div1")[0]
 parent.addEventListener("click",()=>{
    alert("You clicked the parent")
    console.log("Parent clicked")
 })

 let child1=document.getElementsByClassName("div2")[0]
 const event1=(e)=>{
    alert("You clicked the child1")
    remove()
    
 }

 child1.addEventListener("click",event1)
 const remove=()=>{
    child1.removeEventListener("click",event1)
 }
 //once it is clicked the event listener is removed and wont work again.once child1 is clicked alert is produced.after that alert is not produced for child1
 
 let child2=document.getElementsByClassName("div3")[0]
 child2.addEventListener("click",(e)=>{
    alert("You clicked the child2")
    console.log("child 2 clicked")
    e.stopPropagation
 })

const catchKeyboard=(e)=>{
    console.log(e)
}

window.addEventListener("keydown",catchKeyboard)
