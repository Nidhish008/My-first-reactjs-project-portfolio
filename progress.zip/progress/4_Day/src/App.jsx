import Header from "./Header.jsx"
import Content from "./Content.jsx"
import Footer from "./Footer.jsx"
import Content_1 from "./Content_1.jsx"
import Content_2 from "./Content_2.jsx"
import React from "react"
function App() {
  return (
    <>
    <Header/>
    <Content/>
    <Content_1/>
    <Content_2/>
    <Footer/>
    </>  
  )
}

export default App
