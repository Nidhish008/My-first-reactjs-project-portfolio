import React from 'react'

const Content=()=>{
  return (
    <div>
        <h1>Content</h1>
        <p>Loremipsum lorem ipsum lorem ipsum lorem ipsum</p>
    </div>
  )
}

export default Content;