const Header=()=>{
    return(
        <div><ul>
            <li>Home</li>
            <li>Products</li>
            <li>Contact</li>
        </ul></div>

    )        
}
export default Header;


