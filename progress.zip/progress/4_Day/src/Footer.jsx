import React from 'react'

const Footer=()=> {
  return (
    <div>
        <h1>Footer</h1>
        <p>This is a footer message</p>
    </div>
  )
}

export default Footer