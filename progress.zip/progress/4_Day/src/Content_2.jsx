import React from 'react'

const Content_2 = () => {
  return (
    <div>content-2</div>
  )
}

export default Content_2