import React from 'react'


const Add = () => {
  return (
    <div>Addition performed</div>
  )
}

const Content_1 = () => {
  return (
    <>
    <div>content-1</div>
    <Add/>
    </>
  )
}




export default Content_1