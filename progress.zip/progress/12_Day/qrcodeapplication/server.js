const { log } = require("console")
const express = require("express")
const qr = require("qrcode")
const path = require("path")
const app = express()
app.use(express.json())

app.use(express.static(path.join(__dirname, "public")))
app.get("/home", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "index.html"))
})
app.post("/qr", async(req, res) => {
    let link = req.body.data
    let genQr = await qr.toDataURL(link)
    res.json(genQr)

})

app.get("/qr",async(req,res)=>{
    let link = req.query.link;
    let genQr = await qr.toDataURL(link)
    res.json(genQr)
})

app.listen(3000, () => {
    console.log("server is running");
})