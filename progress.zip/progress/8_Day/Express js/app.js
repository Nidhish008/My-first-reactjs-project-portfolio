// //custom event

// // const events=require("events")
// // const customEvent=new events.EventEmitter()
// // customEvent.on("cs",()=>{
// //     console.log("custom event is triggered");
// // })
// // customEvent.emit("cs")



// //express js
// const express=require("express")
// const app=express()
// app.get("/",(req,res)=>{
//     //res.json({ok:true})
//     console.log("server called");
//     res.status(200).sendFile(__dirname+'/index.html');
//     res.setHeader("Content-type","text/html")
// })
// app.listen(2000,()=>{
//     console.log("Server is running in https://localhost:2000")
// })



//api server

const express=require("express")
const fs=require("fs")
const path=require("path")
const app=express()
app.use(express.json())
const jsonData=JSON.parse(fs.readFileSync(path.join(__dirname,"model","product.json"),"utf-8"))

app.get("/api/v1/products",(req,res)=>{
    console.log("h");
    
try{
    res.status(200).json({
        status:"fulfilled",
        count:jsonData.length,
        data:{
            products:jsonData
        }
    })
}
catch(error){
    res.status(500).json({
        status:"fail",
        message:error
        })
    }
})

app.get("/api/v1/products/:id",(req,res)=>{
    let id=req.params.id*1;
    const data1=jsonData.find((i)=>i.id===id)
    try{
        res.status(200).json({
            status:"fulfilled",
            count:data1.length,
            data:{
                products:data1
            }
        })
    }
    catch(error){
        res.status(500).json({
            status:"fail",
            message:error
        })
    }
})

 app.get("/*",(req,res)=>{
    res.json({status:"fail"})
 })

app.post("/api/v1/products",(req,res)=>{
    const id=jsonData.length+1
    const newProduct={...req.body,id:id}
    jsonData.push(newProduct)
        fs.writeFile(path.join(__dirname,"model","product.json"),JSON.stringify(jsonData))
            res.status(200).json({
                status:"fulfilled",
                count:jsonData.length,
                data:{
                    products:jsonData
                }
})

app.listen(1000,()=>{
    console.log("Server is running in https://127.0.0.1:1000")
})


})