const express=require("express");
const path=require("path");
const app=express()
const {ExpressHandlebars,engine}=require("express-handlebars")
app.use(express.static(path.join(__dirname,"public")))
//app.set("view engine","pug")
//app.set("view engine","ejs")
app.engine("hbs",engine({extname:"hbs",defaultLayout:false}))
app.set("view engine","hbs")
app.get('/home',(req,res)=>{
    let data="text value"
    let arr=[1,2,3,4,5]
    res.render("index",{data,arr});
})
app.get('/about',(req,res)=>{
    let arr=[1,2,3,4,5]
    res.render("about",{arr});
})
app.get('/contact',(req,res)=>{
    res.render("contact");
})
app.listen(3000,()=>console.log("Server is running"))
